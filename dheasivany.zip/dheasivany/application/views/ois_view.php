<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>

  <title>Curriculum Vitae</title> <!-- Judul pada suatu web-->

</head>

<body bgcolor="#bluesky" width="800px"> <!-- Membuat body memiliki warna dengan menggunakan bgcolor -->

  <div align="center">

   <!-- Membuat rata tengah-->

   <center>

    <h1>

    Curiculum Vitae</h1>

    <!-- Membuat huruf menjadi besar (Ukuran H1) -->

  </center>

  <hr/>

  <h2>

  DATA DIRI</h2>

  <!-- Membuat huruf menjadi besar (Ukuran H2) -->

  <table width="800px"> <!-- Membuat sebuah table -->
<tbody>

    <tr>

      <td width="25%">Nama</td>

      <td width="1%">:</td>

      <td><b>Dhea Sivany</b></td>

      <td rowspan="4"><img src="assets/image/3.jpg" height='200px' width='200px'></td>

    </tr>

    <tr>

      <td>Tempat Tanggal Lahir </td>

      <td>:</td>

      <td>Bandung, 12 Mei 2002 </td>

    </tr>

    <tr>

      <td>Alamat</td>

      <td>:</td>

      <td>jl.Arumanis Rancakalong/Rancakendal</td>

    </tr>

    <tr>

      <td>E-mail</td>

      <td>:</td>

      <td>dheasivany16@gmail.com</td>

    </tr>

  </tbody>

</table>

<h2>

RIWAYAT SEKOLAH</h2>

<table width="800px">

  <tbody>

    <tr>

      <td width="25%">2017-Sekarang</td>

      <td width="1%">:</td>

      <td>SMK AL FALAH BANDUNG</td>

    </tr>

    <tr>

      <td>2014-2017</td>

      <td>:</td>

      <td>SMPN 19 BANDUNG</td>

      <tr>

        <td>2008-2014</td>

        <td>:</td>

        <td>SDN 1 CIGADUNG</td>

      </tr>

   </tbody>

    </body>

    </html> 
 
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>